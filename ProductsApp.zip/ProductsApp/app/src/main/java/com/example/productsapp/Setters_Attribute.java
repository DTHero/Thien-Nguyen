package com.example.productsapp;

import android.databinding.BindingAdapter;
import android.graphics.Paint;
import android.widget.TextView;

/**
 * Created by intern.ntthien on 7/3/2017.
 */

public class Setters_Attribute {
    @BindingAdapter({"app:strike"})
    public static void setStrike(TextView view, boolean change) {
        if(change==true)
        view.setPaintFlags(view.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
    }
}
