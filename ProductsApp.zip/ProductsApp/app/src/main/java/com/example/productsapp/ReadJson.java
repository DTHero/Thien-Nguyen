package com.example.productsapp;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by intern.ntthien on 6/28/2017.
 */

public class ReadJson {
    public static String readProductsJSONFile(Context context) throws IOException, JSONException {

        InputStream is = context.getResources().openRawResource(R.raw.productjson);
        BufferedReader br= new BufferedReader(new InputStreamReader(is));
        StringBuilder sb= new StringBuilder();
        String s= null;
        while((  s = br.readLine())!=null) {
            sb.append(s);
            sb.append("\n");
        }
        String jsonText = sb.toString();

        return jsonText;
    }
}
