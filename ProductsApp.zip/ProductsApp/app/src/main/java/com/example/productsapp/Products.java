package com.example.productsapp;

import android.content.Intent;

public class Products {
    private int id;
    private String name;
    private int min_price;
    private int original_price;
    private String value;
    private String imgLink;

    public int getId() { return this.id;}
    public String getName() { return this.name;}
    public int getMin_price(){ return this.min_price;}
    public int getOriginal_price(){ return this.original_price;}
    public String getValue(){ return this.value;}
    public String getImgLink(){ return this.imgLink;}

    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setMin_rice(int min_price) {
        this.min_price = min_price;
    }
    public void setOriginal_price(int original_price) {
        this.original_price = original_price;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }
}
