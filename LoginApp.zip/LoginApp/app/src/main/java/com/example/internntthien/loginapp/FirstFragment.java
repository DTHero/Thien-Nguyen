package com.example.internntthien.loginapp;

import android.support.v4.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by intern.ntthien on 6/22/2017.
 */

public class FirstFragment extends Fragment {
    private TextView name;
    private TextView position;
    private Login login;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.activity_first, container, false);
        name = (TextView) view.findViewById(R.id.name);
        position = (TextView) view.findViewById(R.id.position);
        applyText();
        return view;
    }
    public void showText(String username) {
        if(username.equals("luonganhtuan")) {
            name.setText("tuan luong anh");
            position.setText("Lead Team");
        }
        else if(username.equals("nguyenthanhphuong")) {
            name.setText("phuong nguyen thanh");
            position.setText("Engineer");
        }
        else if(username.equals("duongtrungvietanh")) {
            name.setText("anh duong trung viet");
            position.setText("Technical");
        }
        else if(username.equals("nguyenthanhthien")) {
            name.setText("thien nguyen thanh");
            position.setText("Internship");
        }
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Login) {
            this.login = (Login) context;
        }
    }
    private void applyText() {
        this.login.showContent();
    }
}